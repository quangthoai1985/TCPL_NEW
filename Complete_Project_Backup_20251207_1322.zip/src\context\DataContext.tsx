
'use client';

import React, { createContext, useContext, useState, ReactNode, useEffect, useCallback } from 'react';
import {
    type User,
    type Unit,
    type AssessmentPeriod,
    type Assessment,
    type Role,
    type Criterion,
    type Document as AppDocument,
    type LoginConfig,
    type IndicatorResult,
    type Indicator,
} from '@/lib/data';
import { initializeApp, getApp, getApps, FirebaseOptions, type FirebaseApp } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, setDoc, writeBatch, type Firestore, deleteDoc, getDoc, onSnapshot, query, where, Unsubscribe } from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut, User as FirebaseUser, type Auth } from 'firebase/auth';
import { getStorage, ref, deleteObject, type FirebaseStorage } from 'firebase/storage';
import { getFunctions, type Functions } from 'firebase/functions';
import FirebaseErrorListener from '@/components/FirebaseErrorListener';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

const firebaseConfig: FirebaseOptions = {
    apiKey: "AIzaSyCj0H_a8O7znR_M1bFim9Lzt5MfnsptxH4",
    authDomain: "chuan-tiep-can-pl.firebaseapp.com",
    projectId: "chuan-tiep-can-pl",
    storageBucket: "chuan-tiep-can-pl.firebasestorage.app",
    messagingSenderId: "851876581009",
    appId: "1:851876581009:web:60bfbcc40055f76f607930"
};

const getFirebaseServices = () => {
    if (typeof window === 'undefined') {
        return { app: null, db: null, auth: null, storage: null, functions: null };
    }
    const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
    const db = getFirestore(app);
    const auth = getAuth(app);
    const storage = getStorage(app);
    const functions = getFunctions(app, 'asia-east1');
    return { app, db, auth, storage, functions };
};

export type Notification = {
    id: string;
    title: string;
    time: string;
    read: boolean;
    link: string;
};

interface DataContextType {
    loading: boolean;
    refreshData: () => Promise<void>;
    users: User[];
    updateUsers: (newUsers: User[]) => Promise<void>;
    units: Unit[];
    updateUnits: (newUnits: Unit[]) => Promise<void>;
    assessmentPeriods: AssessmentPeriod[];
    updateAssessmentPeriods: (newPeriods: AssessmentPeriod[]) => Promise<void>;
    assessments: Assessment[];
    updateAssessments: (newAssessments: Assessment[]) => Promise<void>;
    updateSingleAssessment: (assessment: Assessment) => Promise<void>;
    deleteAssessment: (assessmentId: string) => Promise<void>;
    criteria: Criterion[];
    updateCriteria: (newCriteria: Criterion[]) => Promise<void>;
    setCriteria: React.Dispatch<React.SetStateAction<Criterion[]>>; // Thêm hàm setCriteria
    guidanceDocuments: AppDocument[];
    updateGuidanceDocuments: (newDocs: AppDocument[]) => Promise<void>;
    loginConfig: LoginConfig | null;
    updateLoginConfig: (newConfig: LoginConfig) => Promise<void>;
    deleteFileByUrl: (fileUrl: string) => Promise<void>;
    role: Role | null;
    currentUser: User | null;
    notifications: Notification[];
    markNotificationAsRead: (notificationId: string) => void;
    setLoginInfo: (email: string, password: string) => Promise<boolean>;
    logout: () => Promise<void>;
    storage: FirebaseStorage | null;
    functions: Functions | null;
    db: Firestore | null;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider = ({ children }: { children: ReactNode }) => {
    const [db, setDb] = useState<Firestore | null>(null);
    const [auth, setAuth] = useState<Auth | null>(null);
    const [storage, setStorage] = useState<FirebaseStorage | null>(null);
    const [functions, setFunctions] = useState<Functions | null>(null);

    const [loading, setLoading] = useState(true);
    const [users, setUsers] = useState<User[]>([]);
    const [units, setUnits] = useState<Unit[]>([]);
    const [assessmentPeriods, setAssessmentPeriods] = useState<AssessmentPeriod[]>([]);
    const [assessments, setAssessments] = useState<Assessment[]>([]);
    const [criteria, setCriteria] = useState<Criterion[]>([]);
    const [guidanceDocuments, setGuidanceDocuments] = useState<AppDocument[]>([]);
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [loginConfig, setLoginConfig] = useState<LoginConfig | null>(null);

    const [role, setRole] = useState<Role | null>(null);
    const [currentUser, setCurrentUser] = useState<User | null>(null);

    useEffect(() => {
        const services = getFirebaseServices();
        if (services.db) setDb(services.db);
        if (services.auth) setAuth(services.auth);
        if (services.storage) setStorage(services.storage);
        if (services.functions) setFunctions(services.functions);
    }, []);

    const getUnitName = (unitId: string, allUnits: Unit[]) => {
        return allUnits.find(u => u.id === unitId)?.name || 'Không xác định';
    }

    const generateNotifications = (user: User | null, allAssessments: Assessment[], allUnits: Unit[]) => {
        if (!user) return [];

        const generated: Notification[] = [];
        const sortedAssessments = [...allAssessments].sort((a, b) => (b.registrationSubmissionDate || b.assessmentSubmissionDate || '').localeCompare(a.registrationSubmissionDate || a.assessmentSubmissionDate || ''));

        if (user.role === 'admin') {
            sortedAssessments.forEach(assessment => {
                if (assessment.registrationStatus === 'pending') {
                    const communeName = getUnitName(assessment.communeId, allUnits);
                    generated.push({
                        id: `admin-notif-reg-${assessment.id}`,
                        title: `${communeName} vừa gửi yêu cầu đăng ký.`,
                        time: `Ngày ${assessment.registrationSubmissionDate}`,
                        read: false,
                        link: `/admin/registrations?tab=pending`
                    });
                }
                if (assessment.assessmentStatus === 'pending_review') {
                    const communeName = getUnitName(assessment.communeId, allUnits);
                    generated.push({
                        id: `admin-notif-${assessment.id}`,
                        title: `${communeName} vừa gửi hồ sơ đánh giá.`,
                        time: `Ngày ${assessment.assessmentSubmissionDate}`,
                        read: false,
                        link: `/admin/reviews/${assessment.id}`
                    });
                }
            });

        } else { // commune_staff
            const userAssessments = sortedAssessments.filter(a => a.communeId === user.communeId);
            userAssessments.forEach(assessment => {
                if (assessment.registrationStatus === 'approved') {
                    generated.push({
                        id: `commune-reg-approved-${assessment.id}`,
                        title: `Đăng ký của bạn đã được duyệt.`,
                        time: `Bây giờ bạn có thể bắt đầu tự đánh giá.`,
                        read: false,
                        link: `/commune/assessments`
                    });
                }
                if (assessment.registrationStatus === 'rejected') {
                    generated.push({
                        id: `commune-reg-rejected-${assessment.id}`,
                        title: `Đăng ký của bạn đã bị từ chối/bị trả lại.`,
                        time: `Vui lòng xem chi tiết và gửi lại.`,
                        read: false,
                        link: `/dashboard`
                    });
                }
                if (assessment.assessmentStatus === 'achieved_standard') {
                    generated.push({
                        id: `commune-approved-${assessment.id}`,
                        title: `Chúc mừng! Hồ sơ của bạn đã được công nhận Đạt Chuẩn.`,
                        time: `Ngày ${assessment.approvalDate}`,
                        read: false,
                        link: `/admin/reviews/${assessment.id}`
                    });
                }
                if (assessment.assessmentStatus === 'rejected') {
                    generated.push({
                        id: `commune-rejected-${assessment.id}`,
                        title: `Rất tiếc, hồ sơ của bạn đã bị đánh giá là Không Đạt.`,
                        time: `Ngày ${assessment.approvalDate}`,
                        read: false,
                        link: `/admin/reviews/${assessment.id}`
                    });
                }
                if (assessment.assessmentStatus === 'returned_for_revision') {
                    generated.push({
                        id: `commune-returned-${assessment.id}`,
                        title: `Hồ sơ của bạn đã được trả lại để bổ sung/chỉnh sửa.`,
                        time: `Vui lòng xem chi tiết ghi chú của Admin.`,
                        read: false,
                        link: `/admin/reviews/${assessment.id}`
                    });
                }
            });
        }

        const uniqueNotifications = Array.from(new Map(generated.map(item => [item.id, item])).values());
        return uniqueNotifications.slice(0, 15);
    };


    useEffect(() => {
        if (!auth || !db) return;

        let allUnsubs: Unsubscribe[] = [];

        const unsubAuth = onAuthStateChanged(auth, async (firebaseUser) => {
            // Hủy đăng ký tất cả các listener cũ trước khi thiết lập những listener mới
            allUnsubs.forEach(unsub => unsub());
            allUnsubs = [];

            setLoading(true);

            // Luôn fetch các collection public ngay cả khi chưa đăng nhập
            const configDocRef = doc(db, 'configurations', 'loginPage');
            const unsubConfig = onSnapshot(configDocRef, (docSnap) => {
                if (docSnap.exists()) {
                    setLoginConfig(docSnap.data() as LoginConfig);
                } else {
                    setLoginConfig(null);
                }
            }, (error) => {
                console.error("Error fetching login config:", error);
                errorEmitter.emit('permission-error', new FirestorePermissionError({
                    path: configDocRef.path,
                    operation: 'get'
                }));
            });
            allUnsubs.push(unsubConfig);

            const guidanceQuery = query(collection(db, 'guidanceDocuments'));
            const unsubGuidance = onSnapshot(guidanceQuery,
                (snap) => setGuidanceDocuments(snap.docs.map(d => d.data() as AppDocument)),
                (error) => {
                    console.error("Error fetching guidanceDocuments:", error);
                    errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'guidanceDocuments', operation: 'list' }));
                    setGuidanceDocuments([]);
                }
            );
            allUnsubs.push(unsubGuidance);

            if (firebaseUser) {
                const userDocRef = doc(db, 'users', firebaseUser.uid);

                try {
                    const userDocSnap = await getDoc(userDocRef);

                    if (userDocSnap.exists()) {
                        const loggedInUser = userDocSnap.data() as User;
                        setCurrentUser(loggedInUser);
                        setRole(loggedInUser.role);

                        const commonCollections = ['units', 'assessmentPeriods', 'criteria'];
                        commonCollections.forEach(colName => {
                            const q = query(collection(db, colName));
                            let unsub;
                            switch (colName) {
                                case 'units':
                                    unsub = onSnapshot(q,
                                        (snap) => setUnits(snap.docs.map(d => d.data() as Unit)),
                                        (error) => {
                                            console.error(`Error fetching ${colName}:`, error);
                                            errorEmitter.emit('permission-error', new FirestorePermissionError({ path: colName, operation: 'list' }));
                                            setUnits([]);
                                        }
                                    );
                                    allUnsubs.push(unsub);
                                    break;
                                case 'assessmentPeriods':
                                    unsub = onSnapshot(q,
                                        (snap) => setAssessmentPeriods(snap.docs.map(d => d.data() as AssessmentPeriod)),
                                        (error) => {
                                            console.error(`Error fetching ${colName}:`, error);
                                            errorEmitter.emit('permission-error', new FirestorePermissionError({ path: colName, operation: 'list' }));
                                            setAssessmentPeriods([]);
                                        }
                                    );
                                    allUnsubs.push(unsub);
                                    break;
                                case 'criteria': {
                                    const unsubCriteria = onSnapshot(query(collection(db, colName)), async (criteriaSnapshot) => {
                                        const criteriaPromises = criteriaSnapshot.docs.map(async (criterionDoc) => {
                                            const criterionData = criterionDoc.data() as Criterion;
                                            const criterionId = criterionDoc.id;
                                            let indicators: Indicator[] = [];

                                            try {
                                                const indicatorsSnapshot = await getDocs(collection(criterionDoc.ref, 'indicators'));

                                                if (indicatorsSnapshot.empty) {
                                                    console.warn(`DataContext: No indicators found in subcollection for ${criterionId}.`);
                                                } else {
                                                    indicators = indicatorsSnapshot.docs.map(indicatorDoc => indicatorDoc.data() as Indicator);
                                                }

                                            } catch (error) {
                                                console.error(`DataContext: Error fetching indicators for ${criterionId}:`, error);
                                                errorEmitter.emit('permission-error', new FirestorePermissionError({ path: `${colName}/${criterionId}/indicators`, operation: 'list' }));
                                                indicators = [];
                                            }

                                            return {
                                                ...criterionData,
                                                indicators: indicators.sort((a, b) => (a.order || 0) - (b.order || 0))
                                            };
                                        });

                                        const fullCriteriaData = await Promise.all(criteriaPromises);
                                        setCriteria(fullCriteriaData);
                                    }, (error) => {
                                        console.error("Error fetching criteria:", error);
                                        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: colName, operation: 'list' }));
                                        setCriteria([]);
                                    });

                                    allUnsubs.push(unsubCriteria);
                                    break;
                                }
                            }
                        });

                        if (loggedInUser.role === 'admin') {
                            const usersQuery = query(collection(db, 'users'));
                            allUnsubs.push(onSnapshot(usersQuery,
                                (snap) => setUsers(snap.docs.map(d => d.data() as User)),
                                (error) => {
                                    console.error("Error fetching users:", error);
                                    errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'users', operation: 'list' }));
                                    setUsers([]);
                                }
                            ));

                            const assessmentsQuery = query(collection(db, 'assessments'));
                            allUnsubs.push(onSnapshot(assessmentsQuery,
                                (snap) => setAssessments(snap.docs.map(d => d.data() as Assessment)),
                                (error) => {
                                    console.error("Error fetching assessments:", error);
                                    errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'assessments', operation: 'list' }));
                                    setAssessments([]);
                                }
                            ));
                        } else {
                            setUsers([]);
                            const assessmentsQuery = query(collection(db, 'assessments'), where("communeId", "==", loggedInUser.communeId));
                            allUnsubs.push(onSnapshot(assessmentsQuery,
                                (snap) => setAssessments(snap.docs.map(d => d.data() as Assessment)),
                                (error) => {
                                    console.error("Error fetching assessments for commune:", error);
                                    errorEmitter.emit('permission-error', new FirestorePermissionError({ path: `assessments where communeId == ${loggedInUser.communeId}`, operation: 'list' }));
                                    setAssessments([]);
                                }
                            ));
                        }
                    } else {
                        console.error("User profile not found, logging out.");
                        await signOut(auth);
                    }
                } catch (error) {
                    console.error("Error fetching user data:", error);
                    await signOut(auth);
                }

            } else {
                setCurrentUser(null);
                setRole(null);
                setUsers([]);
                setAssessments([]);
                setUnits([]);
                setAssessmentPeriods([]);
                setCriteria([]);
                setNotifications([]);
            }
            setLoading(false);
        });

        return () => {
            unsubAuth();
            allUnsubs.forEach(unsub => unsub());
        };
    }, [auth, db]);

    useEffect(() => {
        setNotifications(generateNotifications(currentUser, assessments, units));
    }, [currentUser, assessments, units]);


    const setLoginInfo = async (email: string, password: string): Promise<boolean> => {
        if (!auth) return false;
        setLoading(true);
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            return !!userCredential.user;
        } catch (e) {
            console.error("Login Error: ", e);
            setLoading(false);
            return false;
        }
    };

    const logout = async () => {
        if (!auth) return;
        try {
            await signOut(auth);
        } catch (error) {
            console.error("Error signing out: ", error);
        }
    };

    const createFirestoreUpdater = <T extends { id: string }>(
        collectionName: string
    ) => {
        return async (newData: T[]) => {
            if (!db) return;
            setLoading(true);
            const batch = writeBatch(db);

            const currentStateSnapshot = await getDocs(collection(db, collectionName));
            const currentStateIds = new Set(currentStateSnapshot.docs.map(d => d.id));
            const newStateIds = new Set(newData.map(item => item.id));

            newData.forEach(item => {
                const docRef = doc(db, collectionName, item.id);
                batch.set(docRef, item);
            });

            currentStateIds.forEach(id => {
                if (!newStateIds.has(id)) {
                    const docRef = doc(db, collectionName, id);
                    batch.delete(docRef);
                }
            });

            await batch.commit();
            setLoading(false);
        };
    };

    const updateSingleAssessment = async (assessment: Assessment) => {
        if (!db) return;
        const docRef = doc(db, 'assessments', assessment.id);
        setDoc(docRef, assessment, { merge: true }).catch((error) => {
            errorEmitter.emit('permission-error', new FirestorePermissionError({
                path: docRef.path,
                operation: 'update',
                requestResourceData: assessment,
            }));
            console.error("Update assessment failed:", error);
        });
    };

    const updateLoginConfig = async (newConfig: LoginConfig) => {
        if (!db) return;
        setLoading(true);
        const docRef = doc(db, 'configurations', 'loginPage');
        setDoc(docRef, newConfig, { merge: true })
            .catch((error) => {
                errorEmitter.emit('permission-error', new FirestorePermissionError({
                    path: docRef.path,
                    operation: 'update',
                    requestResourceData: newConfig,
                }));
                console.error("Update login config failed:", error);
            });
        setLoading(false);
    }

    const deleteAssessment = async (assessmentId: string) => {
        if (!db) return;
        setLoading(true);
        const docRef = doc(db, 'assessments', assessmentId);
        deleteDoc(docRef)
            .catch((error) => {
                errorEmitter.emit('permission-error', new FirestorePermissionError({
                    path: docRef.path,
                    operation: 'delete',
                }));
                console.error("Error deleting assessment:", error);
                throw error; // Re-throw to be caught by the caller
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const deleteFileByUrl = async (fileUrl: string) => {
        if (!storage) return;
        try {
            const fileRef = ref(storage, fileUrl);
            await deleteObject(fileRef);
        } catch (error: any) {
            if (error.code !== 'storage/object-not-found') {
                console.error("Error deleting file from storage:", error);
                throw error;
            }
            console.warn("File to delete was not found in Storage, it might have been deleted already.");
        }
    };

    const refreshData = useCallback(async () => {
        console.log("Manual refresh triggered. Data is already real-time.");
        return Promise.resolve();
    }, []);

    const markNotificationAsRead = (notificationId: string) => {
        setNotifications(prevNotifications =>
            prevNotifications.map(n =>
                n.id === notificationId ? { ...n, read: true } : n
            )
        );
    };

    const updateUsers = createFirestoreUpdater('users');
    const updateUnits = createFirestoreUpdater('units');
    const updateAssessmentPeriods = createFirestoreUpdater('assessmentPeriods');
    const updateAssessments = createFirestoreUpdater('assessments');
    const updateCriteria = createFirestoreUpdater('criteria');
    const updateGuidanceDocuments = createFirestoreUpdater('guidanceDocuments');

    return (
        <DataContext.Provider value={{
            loading,
            refreshData,
            users, updateUsers,
            units, updateUnits,
            assessmentPeriods, updateAssessmentPeriods,
            assessments, updateAssessments,
            updateSingleAssessment,
            deleteAssessment,
            deleteFileByUrl,
            criteria, updateCriteria, setCriteria,
            guidanceDocuments, updateGuidanceDocuments,
            loginConfig, updateLoginConfig,
            role,
            currentUser,
            notifications,
            markNotificationAsRead,
            setLoginInfo,
            logout,
            storage,
            functions,
            db,
        }}>
            {process.env.NODE_ENV === 'development' && <FirebaseErrorListener />}
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
